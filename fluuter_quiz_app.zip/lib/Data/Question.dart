class Question {
  String? questionTitle;
  String? imageNameNumber;
  List<String>? answerList;
  int? correctAnswer;
}
