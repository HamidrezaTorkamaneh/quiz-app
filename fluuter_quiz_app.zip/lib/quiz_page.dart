import 'package:flutter/material.dart';
import 'package:flutter_quiz_application/Data/Question.dart';

import 'package:flutter_quiz_application/constants/Constants.dart';
import 'package:flutter_quiz_application/screens/result_screen.dart';

class QizePage extends StatefulWidget {
  const QizePage({super.key});

  @override
  State<QizePage> createState() => _QizePageState();
}

class _QizePageState extends State<QizePage> {
  int shownQuestionIndex = 0;
  bool isFinalAnswerSubmited = false;
  Question? selectedQuestion;
  int correctAnswer = 0;
  @override
  Widget build(BuildContext context) {
    selectedQuestion = getQuestionList()![shownQuestionIndex];
    String imageIndex = selectedQuestion!.imageNameNumber!;
    String titleIndex = selectedQuestion!.questionTitle!;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          ' سوال ${shownQuestionIndex + 1} از ${getQuestionList()!.length}',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.indigo[800],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: double.infinity,
            ),
            Image(
              image: AssetImage('images/$imageIndex.png'),
              height: 300,
            ),
            SizedBox(height: 30.0),
            Text(
              titleIndex,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 30.0),
            ...List.generate(4, (index) => getOptionItem(index)),
            if (isFinalAnswerSubmited)
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[700],
                  minimumSize: Size(200.0, 50.0),
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          ResultScreen(resultAnswer: correctAnswer),
                    ),
                  );
                },
                child: Text(
                  'مشاهده نتایح آزمون',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget getOptionItem(int index) {
    return ListTile(
      title: Text(
        selectedQuestion!.answerList![index],
        textAlign: TextAlign.start,
      ),
      onTap: () {
        if (selectedQuestion!.correctAnswer == index) {
          print('Correct');
          correctAnswer += 1;
        } else {
          print('Error');
        }
        setState(
          () {
            if (shownQuestionIndex < getQuestionList()!.length - 1) {
              shownQuestionIndex++;
            } else if (shownQuestionIndex == getQuestionList()!.length - 1) {
              isFinalAnswerSubmited = true;
            }
          },
        );
      },
    );
  }
}
