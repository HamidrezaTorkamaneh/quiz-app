import 'package:flutter_quiz_application/Data/Question.dart';

List<Question>? getQuestionList() {
  var firstQuestion = Question();
  firstQuestion.questionTitle = 'کدام یک از زبان های زیر تحت وب است ؟';
  firstQuestion.imageNameNumber = 'programming1';
  firstQuestion.correctAnswer = 0;
  firstQuestion.answerList = ['Java script', 'C++', 'C#', 'java'];
  var secondQuestion = Question();
  secondQuestion.questionTitle =
      'کدام یک از زبان های برنامه نویسی زیر برای مایکروسافت است ؟';
  secondQuestion.imageNameNumber = 'programming2';
  secondQuestion.correctAnswer = 1;
  secondQuestion.answerList = ['Unity', 'Dart', 'Java', 'C'];

  var thirdQuestion = Question();
  thirdQuestion.questionTitle =
      'کدام یک از گزینه های زیر زبان برنامه نویسی نیست ؟';
  thirdQuestion.imageNameNumber = 'programming3';
  thirdQuestion.correctAnswer = 2;
  thirdQuestion.answerList = ['Java', 'Flutter', 'HTML', 'Python'];

  var fourthQuestion = Question();
  fourthQuestion.questionTitle =
      'دستور چاپ در فلاتر ، کدام یک از گزینه های زیر است ؟';
  fourthQuestion.imageNameNumber = 'programming4';
  fourthQuestion.correctAnswer = 3;
  fourthQuestion.answerList = [
    'cout>>',
    'print',
    'System.out.println',
    'print(' ')'
  ];

  var fivethQuestion = Question();
  fivethQuestion.questionTitle = 'گدام زبان های زیر تحت موبایل است ؟';
  fivethQuestion.imageNameNumber = 'programming5';
  fivethQuestion.correctAnswer = 2;
  fivethQuestion.answerList = ['C', 'Java script', 'Flutter', 'Python'];
  return [
    firstQuestion,
    secondQuestion,
    thirdQuestion,
    fourthQuestion,
    fivethQuestion,
  ];
}
